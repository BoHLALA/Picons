# uncompyle6 version 3.9.0
# Python bytecode version base 2.7 (62211)
# Decompiled from: Python 3.8.10 (default, Nov 22 2023, 10:22:35) 
# [GCC 9.4.0]
# Embedded file name: /usr/lib/enigma2/python/Components/Renderer/Bhclock.py
# Compiled at: 2021-10-14 16:30:40
from Components.VariableValue import VariableValue
from Renderer import Renderer
from enigma import eGauge

class BOhlala_clock(VariableValue, Renderer):

    def __init__(self):
        Renderer.__init__(self)
        VariableValue.__init__(self)

    GUI_WIDGET = eGauge

    def changed(self, what):
        if what[0] == self.CHANGED_CLEAR:
            return
        else:
            value = self.source.value
            if value is None:
                value = 0
            self.setValue(value)
            return

    GUI_WIDGET = eGauge

    def postWidgetCreate(self, instance):
        instance.setValue(0)

    def setValue(self, value):
        if self.instance is not None:
            self.instance.setValue(value)
        return